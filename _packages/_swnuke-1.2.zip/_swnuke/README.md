# 📦 Bugfish Nuke

## 📙 Information

Security software to delete critical data, for example in case of unexpected warrants and more.

🐟 Bugfish