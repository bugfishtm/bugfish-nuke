using System.Data.SQLite;
using System.Data;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Security.Policy;
using static System.Net.WebRequestMethods;
using System.Media;
using System.Security.Principal;
using System.Diagnostics;
using bugfish_hub.Library;
using System.Threading.Tasks;
using System.IO;
using System;
using System.Linq;

namespace bugfish_hub
{
    public partial class Interface : Form
    {
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;

        private int borderWidth = 10; // Set the width of the border
        private Color borderColor = Color.FromArgb(0x24, 0x24, 0x24); // Set the color of the border
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.Button btnClose;
        private NotifyIcon notifyIcon;
        private ContextMenuStrip contextMenuStrip;
        private Sqlite sqlite;
        private Point offset;
        private System.Windows.Forms.Timer timer1 = new System.Windows.Forms.Timer();
        private Task CurrentTask;
        private bool canceled;
        [DllImport("shell32.dll")]
        static extern int SHEmptyRecycleBin(IntPtr hwnd, string pszRootPath, uint dwFlags);

        public Interface()
        {
            // Ensure Admin Permission
            EnsureRunAsAdmin();

            // Initialize Component
            InitializeComponent();

            // Disable Load Panel
            Panel_Load.Visible = false;

            // Initialize SQLite
            sqlite = new Sqlite("data.db");
            sqlite.CreateTable("CREATE TABLE IF NOT EXISTS Items (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL, Shortcode TEXT NOT NULL UNIQUE, IsActive INTEGER NOT NULL);");
            sqlite.CreateTable("CREATE TABLE IF NOT EXISTS Folders (Id INTEGER PRIMARY KEY AUTOINCREMENT, Path TEXT NOT NULL, IsActive INTEGER NOT NULL);");

            // Fix Interface
            interface_init_frame_btn();

            // Setup Window Icon
            this.Icon = new Icon(new MemoryStream(Properties.Resources.nukeicon));

            // Setup Window Fix Timer
            timer1.Interval = 500;
            timer1.Tick += timer1_Tick;
            timer1.Start();

            // Check for Table Status
            var dt = sqlite.GetDataTable("SELECT COUNT(*) as cnt FROM Items");
            int count = Convert.ToInt32(dt.Rows[0]["cnt"]);

            // Pre Configured Database Items
            var initialItems = new[]
            {
                new { Name = "Brave: Close and Delete User Data", Shortcode = "brave" },
                new { Name = "Signal: Close and Delete User Data", Shortcode = "signal" },
                new { Name = "Mozilla Firefox: Close and Delete User Data", Shortcode = "firefox" },
                new { Name = "Google Chrome: Close and Delete User Data", Shortcode = "chrome" },
                new { Name = "Discord: Close and Delete User Data", Shortcode = "discord" },
                new { Name = "Nextcloud: Close and Delete User Data", Shortcode = "nextcloud" },
                new { Name = "Telegram: Close and Delete User Data", Shortcode = "telegram" },
                new { Name = "Steam: Close and Delete User Data", Shortcode = "steam" },
                new { Name = "Windows: Clear Trash Bin", Shortcode = "windows_trash" }
            };

            // Restore Lost Database Items
            foreach (var item in initialItems)
            {
                var dtCheck = sqlite.GetDataTable(
                    "SELECT COUNT(*) as cnt FROM Items WHERE Shortcode = @shortcode",
                    new SQLiteParameter("@shortcode", item.Shortcode)
                );
                int exists = Convert.ToInt32(dtCheck.Rows[0]["cnt"]);
                if (exists == 0)
                {
                    sqlite.InsertData(
                        "INSERT INTO Items (Name, Shortcode, IsActive) VALUES (@name, @shortcode, @active)",
                        new SQLiteParameter("@name", item.Name),
                        new SQLiteParameter("@shortcode", item.Shortcode),
                        new SQLiteParameter("@active", "0")
                    );
                }
            }

            // Subscribe to the Paint event
            this.FormBorderStyle = FormBorderStyle.None;
            this.Padding = new Padding(borderWidth);
            this.Padding = new Padding(5);
            this.Paint += new PaintEventHandler(Interface_Paint);
            //this.Resize += Interface_Resize;

            // Create and configure ContextMenuStrip
            // contextMenuStrip = new ContextMenuStrip();
            // contextMenuStrip.Items.Add("Show", null, (s, e) => { this.Show(); this.WindowState = FormWindowState.Normal; notifyIcon.Visible = true; });
            // contextMenuStrip.Items.Add("Exit", null, (s, e) => { Application.Exit(); });

            // Create and configure NotifyIcon
            // notifyIcon = new NotifyIcon
            // {
            //     Icon = new Icon(new MemoryStream(Properties.Resources.nukeicon)),
            //     Visible = true,
            //     ContextMenuStrip = contextMenuStrip
            // };
            // notifyIcon.MouseDoubleClick += NotifyIcon_MouseDoubleClick;

            LoadItems();
            listBoxActive.DoubleClick += listBoxActive_DoubleClick;
            listBoxInactive.DoubleClick += listBoxInactive_DoubleClick;
        }

        // Check for Admin Permissions
        public static bool IsAdministrator()
        {
            using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
        }

        // Ensure Admin Permissions
        public static void EnsureRunAsAdmin()
        {
            if (!IsAdministrator())
            {
                // Restart the application with admin rights
                var proc = new ProcessStartInfo
                {
                    UseShellExecute = true,
                    WorkingDirectory = Environment.CurrentDirectory,
                    FileName = Application.ExecutablePath,
                    Verb = "runas" // This triggers the UAC prompt
                };

                try
                {
                    Process.Start(proc);
                }
                catch
                {
                    // User refused the elevation
                    MessageBox.Show("Administrator permissions are required to continue.", "Permission Denied", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                Application.Exit(); // Close the current instance
            }
        }

        // Reload List Items
        private void LoadItems()
        {
            listBoxActive.Items.Clear();
            listBoxInactive.Items.Clear();
            listBox1.Items.Clear();
            listBox2.Items.Clear();

            var dt = sqlite.GetDataTable("SELECT Id, Name, IsActive FROM Items");
            foreach (DataRow row in dt.Rows)
            {
                var item = new ListBoxItem
                {
                    Id = Convert.ToInt32(row["Id"]),
                    Name = row["Name"].ToString()
                };

                if (Convert.ToInt32(row["IsActive"]) == 1)
                {
                    listBoxActive.Items.Add(item);
                    listBox2.Items.Add(item);
                }
                else
                {
                    listBoxInactive.Items.Add(item);
                }
            }

            dt = sqlite.GetDataTable("SELECT Id, Path FROM Folders");
            foreach (DataRow row in dt.Rows)
            {
                var item = new ListBoxItem
                {
                    Id = Convert.ToInt32(row["Id"]),
                    Name = row["Path"].ToString()
                };
                listBox1.Items.Add(item);
                listBox2.Items.Add(item);
            }
        }

        // Set Active to inactive
        private void listBoxActive_DoubleClick(object sender, EventArgs e)
        {
            if (listBoxActive.SelectedItem is ListBoxItem item)
            {
                sqlite.UpdateData("UPDATE Items SET IsActive = 0 WHERE Id = @id",
                    new SQLiteParameter("@id", item.Id));
                LoadItems();
            }
        }

        // Delete a Path
        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string selectedPath = listBox1.SelectedItem.ToString();

                // Delete from the database
                sqlite.InsertData(
                    "DELETE FROM Folders WHERE Path = @path",
                    new SQLiteParameter("@path", selectedPath)
                );

                // Remove from ListBox
                listBox1.Items.Remove(listBox1.SelectedItem);
            }
        }

        // Set Entry to Active
        private void listBoxInactive_DoubleClick(object sender, EventArgs e)
        {
            if (listBoxInactive.SelectedItem is ListBoxItem item)
            {
                sqlite.UpdateData("UPDATE Items SET IsActive = 1 WHERE Id = @id",
                    new SQLiteParameter("@id", item.Id));
                LoadItems();
            }
        }

        // List Box Item Array
        public class ListBoxItem
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public override string ToString() => Name;
        }

        // Interface Paint Functionality
        private void Interface_Paint(object sender, PaintEventArgs e)
        {
            // Draw the custom border
            using (Pen borderPen = new Pen(borderColor, borderWidth))
            {
                e.Graphics.DrawRectangle(borderPen, new Rectangle(0, 0, this.ClientSize.Width - 1, this.ClientSize.Height - 1));
            }
        }

        // Interface Resize Functionality
        private void Interface_Resize(object sender, EventArgs e)
        {
            // Update button locations on resize
            btnMinimize.Location = new Point(this.Width - 95, 5);
            btnMaximize.Location = new Point(this.Width - 65, 5);
            btnClose.Location = new Point(this.Width - 35, 5);
        }

        // Minimize Button Click to Minimize Current Form
        private void BtnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        // Close Window to Tray or Close Completely
        private void BtnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
            //this.Hide();
            //notifyIcon.Visible = true;
        }

        // Maximize Button Click Functionality
        private void BtnMaximize_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
                Rectangle workingArea = Screen.GetWorkingArea(this);
                this.Width = workingArea.Width;
                this.Height = workingArea.Height;
                this.Location = new Point(Math.Max(this.Location.X, workingArea.X),
                          Math.Max(this.Location.Y, workingArea.Y));
            }
        }

        // Drag Window by Holding on Header
        private void Header_Panel_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }

        // Maximize and Minize Windows with Double Click
        private void Header_Panel_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (this.WindowState == FormWindowState.Normal)
                    this.WindowState = FormWindowState.Maximized;
                else if (this.WindowState == FormWindowState.Maximized)
                    this.WindowState = FormWindowState.Normal;
            }
            interface_init_frame_btn();
        }

        // NotifyIcon DoubleClick
        private void NotifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show(); this.WindowState = FormWindowState.Normal; notifyIcon.Visible = true;
        }

        // Initialize Border and Buttons
        private void interface_init_frame_btn()
        {
            // Minimize Button
            btnMinimize = new System.Windows.Forms.Button
            {
                Text = "_",
                Size = new Size(30, 30),
                Location = new Point(this.Width - 95, 5),
                BackColor = Color.FromArgb(0x24, 0x24, 0x24),
                FlatStyle = FlatStyle.Flat
            };
            btnMinimize.FlatAppearance.BorderSize = 0;
            btnMinimize.Click += BtnMinimize_Click;
            btnMinimize.ForeColor = Color.FromArgb(0xFE, 0xDD, 0x56);
            tooltip_frame.SetToolTip(btnMinimize, "Minimize");

            // Maximize Button
            btnMaximize = new System.Windows.Forms.Button
            {
                Text = "O",
                Size = new Size(30, 30),
                Location = new Point(this.Width - 65, 5),
                BackColor = Color.FromArgb(0x24, 0x24, 0x24),
                FlatStyle = FlatStyle.Flat
            };
            btnMaximize.FlatAppearance.BorderSize = 0;
            btnMaximize.Click += BtnMaximize_Click;
            btnMaximize.ForeColor = Color.FromArgb(0xFE, 0xDD, 0x56);
            tooltip_frame.SetToolTip(btnMaximize, "Maximize");

            // Close Button
            btnClose = new System.Windows.Forms.Button
            {
                Text = "X",
                Size = new Size(30, 30),
                Location = new Point(this.Width - 35, 5),
                BackColor = Color.FromArgb(0x24, 0x24, 0x24),
                FlatStyle = FlatStyle.Flat
            };
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += BtnClose_Click;
            btnClose.ForeColor = Color.FromArgb(0xFE, 0xDD, 0x56);
            tooltip_frame.SetToolTip(btnClose, "Close");

            // Add buttons to the form
            this.Controls.Add(btnMinimize);
            this.Controls.Add(btnMaximize);
            this.Controls.Add(btnClose);

            btnClose.BringToFront();
            btnMaximize.BringToFront();
            btnMinimize.BringToFront();

        }

        // ReInitialize Border and Buttons
        private void interface_reinit_frame_btn()
        {
            btnClose.Location = new Point(this.Width - 35, 5);
            btnMaximize.Location = new Point(this.Width - 65, 5);
            btnMinimize.Location = new Point(this.Width - 95, 5);
            btnClose.BringToFront();
            btnMaximize.BringToFront();
            btnMinimize.BringToFront();

            int imageWidth = this.Width;
            int listBoxWidth = imageWidth / 3;

            panel4.Width = listBoxWidth - 7;
            panel3.Width = listBoxWidth - 7;
            panel2.Width = listBoxWidth - 7;

            panel4.Left = 0;
            panel3.Left = panel4.Right;
            panel2.Left = panel3.Right;

        }
        // Allow for resizing by overriding WndProc
        protected override void WndProc(ref Message m)
        {
            const int WM_NCHITTEST = 0x84;
            const int WM_GETMINMAXINFO = 0x24;
            const int HTCLIENT = 1;
            const int HTCAPTION = 2;
            const int HTLEFT = 10;
            const int HTRIGHT = 11;
            const int HTTOP = 12;
            const int HTTOPLEFT = 13;
            const int HTTOPRIGHT = 14;
            const int HTBOTTOM = 15;
            const int HTBOTTOMLEFT = 16;
            const int HTBOTTOMRIGHT = 17;

            switch (m.Msg)
            {
                case WM_NCHITTEST:
                    base.WndProc(ref m);

                    Point pos = PointToClient(new Point(m.LParam.ToInt32()));
                    if (pos.X < borderWidth && pos.Y < borderWidth)
                    {
                        m.Result = (IntPtr)HTTOPLEFT;
                    }
                    else if (pos.X > Width - borderWidth && pos.Y < borderWidth)
                    {
                        m.Result = (IntPtr)HTTOPRIGHT;
                    }
                    else if (pos.X < borderWidth && pos.Y > Height - borderWidth)
                    {
                        m.Result = (IntPtr)HTBOTTOMLEFT;
                    }
                    else if (pos.X > Width - borderWidth && pos.Y > Height - borderWidth)
                    {
                        m.Result = (IntPtr)HTBOTTOMRIGHT;
                    }
                    else if (pos.X < borderWidth)
                    {
                        m.Result = (IntPtr)HTLEFT;
                    }
                    else if (pos.X > Width - borderWidth)
                    {
                        m.Result = (IntPtr)HTRIGHT;
                    }
                    else if (pos.Y < borderWidth)
                    {
                        m.Result = (IntPtr)HTTOP;
                    }
                    else if (pos.Y > Height - borderWidth)
                    {
                        m.Result = (IntPtr)HTBOTTOM;
                    }
                    else
                    {
                        m.Result = (IntPtr)HTCLIENT;
                    }
                    interface_reinit_frame_btn();
                    return;

                case WM_GETMINMAXINFO:
                    MINMAXINFO minMaxInfo = (MINMAXINFO)Marshal.PtrToStructure(m.LParam, typeof(MINMAXINFO));
                    minMaxInfo.ptMinTrackSize.X = 1200; // Minimum width
                    minMaxInfo.ptMinTrackSize.Y = 700; // Minimum height
                    Marshal.StructureToPtr(minMaxInfo, m.LParam, true);
                    interface_reinit_frame_btn();
                    break;
            }
            base.WndProc(ref m);
        }

        // Tick Timer Fix Window Resize Errors
        private void timer1_Tick(object sender, EventArgs e)
        {
            interface_reinit_frame_btn();
        }

        // Function for Mouse Move on Title Bar Selection
        private void header_frame_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                // Capture the offset from the mouse cursor to the form's location
                offset = new Point(e.X, e.Y);
            }
        }

        // Additional Function for MouseMove
        private void header_frame_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                // Move the form with the mouse
                Point newLocation = this.PointToScreen(new Point(e.X, e.Y));
                newLocation.Offset(-offset.X, -offset.Y);

                // Ensure the form stays within the screen bounds
                Screen screen = Screen.FromPoint(newLocation);
                Rectangle screenBounds = screen.Bounds;

                // Adjust newLocation if it goes outside screen bounds
                int newX = Math.Max(screenBounds.Left, Math.Min(screenBounds.Right - this.Width, newLocation.X));
                int newY = Math.Max(screenBounds.Top, Math.Min(screenBounds.Bottom - this.Height, newLocation.Y));

                this.Location = new Point(newX, newY);
            }
        }

        // Show Youtube Page
        private void richTextBox2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "https://www.youtube.com/@BugfishTM",
                UseShellExecute = true
            });
        }

        // Show Github Page
        private void richTextBox3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "https://github.com/bugfishtm/bugfish-nuke",
                UseShellExecute = true
            });
        }

        // Add new Folder Function Reference
        private void label5_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = "Select a folder";
                folderDialog.ShowNewFolderButton = true;
                folderDialog.RootFolder = Environment.SpecialFolder.MyComputer;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    string folderPath = folderDialog.SelectedPath;

                    // Check if the path already exists in the database
                    var dtCheck = sqlite.GetDataTable(
                        "SELECT COUNT(*) as cnt FROM Folders WHERE Path = @path",
                        new SQLiteParameter("@path", folderPath)
                    );
                    int exists = Convert.ToInt32(dtCheck.Rows[0]["cnt"]);

                    if (exists == 0)
                    {
                        // Insert the folder path into the Folders table, with IsActive = 1 (active)
                        sqlite.InsertData(
                            "INSERT INTO Folders (Path, IsActive) VALUES (@path, @active)",
                            new SQLiteParameter("@path", folderPath),
                            new SQLiteParameter("@active", "1")
                        );
                    }
                }
            }
            LoadItems();

        }

        // Start the Process
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            interface_init_frame_btn();
            Panel_Store.Visible = false;
            Panel_Load.Visible = true;
            listBox2.Visible = true;
            progressBar1.Visible = true;
            textBox1.Text = "";
            button2.Enabled = true;
            button1.Enabled = true;
            canceled = false;
            btnMaximize.Enabled = true;
            btnMinimize.Enabled = true;
            btnClose.Enabled = true;
            checkBox1.Enabled = true;
            checkBox1.Checked = false;
        }

        // Cancel Deletion Button
        private async void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Operation is aborting...please wait.";
            canceled = true;
            if(CurrentTask != null) {
                if (CurrentTask.Status == TaskStatus.Running)
                {
                    await Task.Delay(1000);
                }
                else
                {
                    textBox1.Text = "Operation canceled.";
                }
            }
            interface_init_frame_btn();
            Panel_Load.Visible = false;
            listBox2.Visible = false;
            progressBar1.Visible = true;
            Panel_Store.Visible = true;
            button2.Enabled = true;
            button1.Enabled = true;
            btnMaximize.Enabled = true;
            btnMinimize.Enabled = true;
            btnClose.Enabled = true;
            checkBox1.Checked = false;
            checkBox1.Enabled = true;
        }

        // Confirm Deletion Button
        private async void button1_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button1.Enabled = false;
            btnMaximize.Enabled = false;
            btnMinimize.Enabled = false;
            btnClose.Enabled = false;
            canceled = false;
            checkBox1.Enabled = false;
            textBox1.Text = "Starting deletion process...";

            // Delete Section Process
            var dt = sqlite.GetDataTable("SELECT Id, Name, Shortcode FROM Items WHERE IsActive = 1");
            int rowCount = dt.Rows.Count;
            if (rowCount == 0) { rowCount = 1; } else { rowCount = rowCount + 1; }
            progressBar1.Minimum = 0;
            progressBar1.Maximum = rowCount;
            foreach (DataRow row in dt.Rows)
            {
                if (!canceled)
                {
                    progressBar1.Value = progressBar1.Value + 1;
                    // Delete Brave User Data and Close
                    if (row["Shortcode"].Equals("brave"))
                    {
                        textBox1.Text = "Closing and deletion files of: Brave";
                        KillProcesses("brave");
                        string userData = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            @"BraveSoftware\Brave-Browser\User Data"
                        );
                        await Task.Run(() => SecureDeleteDirectoryAsync(userData));
                    }

                    // Delete Brave User Data and Close
                    if (row["Shortcode"].Equals("telegram"))
                    {
                        textBox1.Text = "Closing and deletion files of: Telegram";
                        // Delete Telegram User Data and Close
                        KillProcesses("Telegram");
                        KillProcesses("TelegramDesktop");
                        string userData = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                            "Telegram Desktop");
                        await Task.Run(() => SecureDeleteDirectoryAsync(userData));
                    }

                    // Discord
                    if (row["Shortcode"].Equals("discord"))
                    {
                        textBox1.Text = "Closing and deletion files of: Discord";
                        KillProcesses("Discord");
                        string userData = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                            "discord");
                        await Task.Run(() => SecureDeleteDirectoryAsync(userData));
                    }

                    // Google Chrome
                    if (row["Shortcode"].Equals("chrome"))
                    {
                        textBox1.Text = "Closing and deletion files of: Chrome";
                        KillProcesses("Chrome");
                        string userData = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            @"Google\Chrome\User Data");
                        await Task.Run(() => SecureDeleteDirectoryAsync(userData));
                    }

                    // Signal
                    if (row["Shortcode"].Equals("signal"))
                    {
                        textBox1.Text = "Closing and deletion files of: Signal";
                        KillProcesses("Signal");
                        string userData = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                            "Signal");
                        await Task.Run(() => SecureDeleteDirectoryAsync(userData));
                    }

                    if (row["Shortcode"].Equals("firefox"))
                    {
                        textBox1.Text = "Closing and deletion files of: firefox";
                        KillProcesses("firefox");
                        string userData = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                            @"Mozilla\Firefox\Profiles");
                        await Task.Run(() => SecureDeleteDirectoryAsync(userData));
                    }

                    if (row["Shortcode"].Equals("nextcloud"))
                    {
                        textBox1.Text = "Closing and deletion files of: Nextcloud";
                        KillProcesses("Nextcloud");
                        string userData = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                            "Nextcloud");
                        await Task.Run(() => SecureDeleteDirectoryAsync(userData));
                    }
                    

                    if (row["Shortcode"].Equals("steam"))
                    {
                        textBox1.Text = "Closing and deletion files of: steam";
                        KillProcesses("Steam");
                        string userData = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                            "Steam");
                        await Task.Run(() => SecureDeleteDirectoryAsync(userData));
                        userData = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            "Steam");
                        await Task.Run(() => SecureDeleteDirectoryAsync(userData));
                    }

                    if (row["Shortcode"].Equals("windows_trash"))
                    {
                        SHEmptyRecycleBin(IntPtr.Zero, null, 0x7);
                    }
                        
                }
            }

            // Delete Folder Process
            dt = sqlite.GetDataTable("SELECT Id, Path FROM Folders");
            rowCount = dt.Rows.Count;
            if (rowCount == 0) { rowCount = 1; } else { rowCount = rowCount + 1; }
            progressBar1.Minimum = 0;
            progressBar1.Value = 0;
            progressBar1.Maximum = rowCount;
            foreach (DataRow row in dt.Rows)
            {
                progressBar1.Value = progressBar1.Value + 1;
                if (!canceled)
                {
                    var currentf = $@"{row["Path"]}";
                    textBox1.Text = "Secure delting folder: "+ currentf;
                    await Task.Run(() => SecureDeleteDirectoryAsync(currentf));
                }
            }


            if (!canceled)
            {
                if(checkBox1.Checked)
                {
                    Process.Start("shutdown", "/r /t 0");
                }
            }

            // Finish the deletion Process
            progressBar1.Value = rowCount;
            if (!canceled) { textBox1.Text = "Finished deletion process..."; }
            button2.Enabled = true;
            button1.Enabled = true;
            canceled = false;
            btnMaximize.Enabled = true;
            btnMinimize.Enabled = true;
            btnClose.Enabled = true;
            checkBox1.Checked = false;
            checkBox1.Enabled = true;
        }

        // Helper to kill all processes by name
        void KillProcesses(params string[] processNames)
        {
            foreach (var name in processNames)
            {
                foreach (var proc in Process.GetProcessesByName(name))
                {
                    try { proc.Kill(true); proc.WaitForExit(); }
                    catch { }
                }
            }
        }

        // Secure Delete Async Function
        public static Task SecureDeleteDirectoryAsync(string dirPath, int passes = 1)
        {
            return Task.Run(() => SecureDelete.SecureDeleteDirectory(dirPath, passes));
        }

        // Extra Function for Minimum Resizing in Width and Height to not make the Window Disappear
        [StructLayout(LayoutKind.Sequential)]
        public struct MINMAXINFO
        {
            public Point ptReserved;
            public Point ptMaxSize;
            public Point ptMaxPosition;
            public Point ptMinTrackSize;
            public Point ptMaxTrackSize;
        }
    }
}
