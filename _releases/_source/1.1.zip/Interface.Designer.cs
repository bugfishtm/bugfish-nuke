﻿namespace bugfish_hub
{
    partial class Interface
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Interface));
            Header_Panel = new Panel();
            label8 = new Label();
            label7 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            Panel_Store = new Panel();
            richTextBox3 = new RichTextBox();
            richTextBox2 = new RichTextBox();
            richTextBox1 = new RichTextBox();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            panel4 = new Panel();
            label5 = new Label();
            listBox1 = new ListBox();
            panel3 = new Panel();
            label4 = new Label();
            listBoxInactive = new ListBox();
            panel2 = new Panel();
            label3 = new Label();
            listBoxActive = new ListBox();
            tooltip_frame = new ToolTip(components);
            bindingSource1 = new BindingSource(components);
            contextMenuStrip1 = new ContextMenuStrip(components);
            Panel_Load = new Panel();
            textBox1 = new TextBox();
            checkBox1 = new CheckBox();
            button2 = new Button();
            button1 = new Button();
            label6 = new Label();
            listBox2 = new ListBox();
            progressBar1 = new ProgressBar();
            Header_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            Panel_Store.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            Panel_Load.SuspendLayout();
            SuspendLayout();
            // 
            // Header_Panel
            // 
            Header_Panel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            Header_Panel.BackColor = Color.FromArgb(24, 24, 24);
            Header_Panel.Controls.Add(label8);
            Header_Panel.Controls.Add(label7);
            Header_Panel.Controls.Add(pictureBox1);
            Header_Panel.Controls.Add(label1);
            Header_Panel.Controls.Add(label2);
            Header_Panel.Location = new Point(0, 0);
            Header_Panel.Name = "Header_Panel";
            Header_Panel.Size = new Size(1099, 100);
            Header_Panel.TabIndex = 0;
            Header_Panel.MouseDoubleClick += Header_Panel_MouseDoubleClick;
            Header_Panel.MouseDown += Header_Panel_MouseDown;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.ForeColor = Color.White;
            label8.Location = new Point(641, 69);
            label8.Name = "label8";
            label8.Size = new Size(438, 20);
            label8.TabIndex = 5;
            label8.Text = "Feature missing? Contact me at nuke@bugfish.eu, I will take care.";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 10F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(994, 46);
            label7.Name = "label7";
            label7.Size = new Size(93, 23);
            label7.TabIndex = 4;
            label7.Text = "Version 1.1";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(104, 95);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.ForeColor = Color.White;
            label1.Location = new Point(113, 9);
            label1.Name = "label1";
            label1.Size = new Size(58, 20);
            label1.TabIndex = 2;
            label1.Text = "Bugfish";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 40F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(113, 9);
            label2.Name = "label2";
            label2.Size = new Size(207, 89);
            label2.TabIndex = 3;
            label2.Text = "NUKE";
            // 
            // Panel_Store
            // 
            Panel_Store.BackColor = Color.FromArgb(12, 12, 12);
            Panel_Store.Controls.Add(richTextBox3);
            Panel_Store.Controls.Add(richTextBox2);
            Panel_Store.Controls.Add(richTextBox1);
            Panel_Store.Controls.Add(pictureBox2);
            Panel_Store.Controls.Add(panel1);
            Panel_Store.Dock = DockStyle.Fill;
            Panel_Store.Location = new Point(0, 0);
            Panel_Store.Name = "Panel_Store";
            Panel_Store.Size = new Size(1099, 633);
            Panel_Store.TabIndex = 1;
            // 
            // richTextBox3
            // 
            richTextBox3.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            richTextBox3.BackColor = Color.FromArgb(12, 12, 12);
            richTextBox3.BorderStyle = BorderStyle.None;
            richTextBox3.ForeColor = Color.Gold;
            richTextBox3.Location = new Point(12, 502);
            richTextBox3.Name = "richTextBox3";
            richTextBox3.ReadOnly = true;
            richTextBox3.Size = new Size(447, 52);
            richTextBox3.TabIndex = 11;
            richTextBox3.Text = "Visit this software's github profile:\nhttps://github.com/bugfishtm/bugfish-nuke";
            richTextBox3.Click += richTextBox3_Click;
            // 
            // richTextBox2
            // 
            richTextBox2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            richTextBox2.BackColor = Color.FromArgb(12, 12, 12);
            richTextBox2.BorderStyle = BorderStyle.None;
            richTextBox2.ForeColor = Color.Gold;
            richTextBox2.Location = new Point(12, 560);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.ReadOnly = true;
            richTextBox2.Size = new Size(447, 52);
            richTextBox2.TabIndex = 10;
            richTextBox2.Text = "Visit my Youtube Channel:\nhttps://www.youtube.com/@BugfishTM";
            richTextBox2.Click += richTextBox2_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            richTextBox1.BackColor = Color.FromArgb(12, 12, 12);
            richTextBox1.BorderStyle = BorderStyle.None;
            richTextBox1.ForeColor = Color.Gold;
            richTextBox1.Location = new Point(487, 494);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.ReadOnly = true;
            richTextBox1.Size = new Size(447, 127);
            richTextBox1.TabIndex = 8;
            richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // pictureBox2
            // 
            pictureBox2.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox2.Location = new Point(940, 494);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(136, 118);
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.FromArgb(12, 12, 12);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(3, 101);
            panel1.Name = "panel1";
            panel1.Size = new Size(1093, 387);
            panel1.TabIndex = 9;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            panel4.BackColor = Color.FromArgb(12, 12, 12);
            panel4.Controls.Add(label5);
            panel4.Controls.Add(listBox1);
            panel4.Location = new Point(696, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(388, 374);
            panel4.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 20F);
            label5.ForeColor = Color.Gold;
            label5.Location = new Point(0, 0);
            label5.Name = "label5";
            label5.Size = new Size(210, 46);
            label5.TabIndex = 7;
            label5.Text = "FOLDERS (+)";
            label5.Click += label5_Click;
            // 
            // listBox1
            // 
            listBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listBox1.BackColor = Color.FromArgb(12, 12, 12);
            listBox1.Font = new Font("Segoe UI", 10F);
            listBox1.ForeColor = SystemColors.InactiveBorder;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 23;
            listBox1.Location = new Point(3, 51);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(377, 303);
            listBox1.TabIndex = 6;
            listBox1.DoubleClick += listBox1_DoubleClick;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            panel3.BackColor = Color.FromArgb(12, 12, 12);
            panel3.Controls.Add(label4);
            panel3.Controls.Add(listBoxInactive);
            panel3.Location = new Point(360, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(330, 374);
            panel3.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI", 20F);
            label4.ForeColor = Color.Red;
            label4.Location = new Point(0, 2);
            label4.Name = "label4";
            label4.Size = new Size(161, 46);
            label4.TabIndex = 5;
            label4.Text = "INACTIVE";
            // 
            // listBoxInactive
            // 
            listBoxInactive.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listBoxInactive.BackColor = Color.FromArgb(12, 12, 12);
            listBoxInactive.Font = new Font("Segoe UI", 10F);
            listBoxInactive.ForeColor = SystemColors.InactiveBorder;
            listBoxInactive.FormattingEnabled = true;
            listBoxInactive.ItemHeight = 23;
            listBoxInactive.Location = new Point(0, 51);
            listBoxInactive.Name = "listBoxInactive";
            listBoxInactive.Size = new Size(324, 303);
            listBoxInactive.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            panel2.BackColor = Color.FromArgb(12, 12, 12);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(listBoxActive);
            panel2.Location = new Point(3, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(351, 374);
            panel2.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 20F);
            label3.ForeColor = Color.LawnGreen;
            label3.Location = new Point(0, 2);
            label3.Name = "label3";
            label3.Size = new Size(127, 46);
            label3.TabIndex = 4;
            label3.Text = "ACTIVE";
            // 
            // listBoxActive
            // 
            listBoxActive.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listBoxActive.BackColor = Color.FromArgb(12, 12, 12);
            listBoxActive.Font = new Font("Segoe UI", 10F);
            listBoxActive.ForeColor = SystemColors.InactiveBorder;
            listBoxActive.FormattingEnabled = true;
            listBoxActive.ItemHeight = 23;
            listBoxActive.Location = new Point(3, 51);
            listBoxActive.Name = "listBoxActive";
            listBoxActive.Size = new Size(345, 303);
            listBoxActive.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // Panel_Load
            // 
            Panel_Load.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Panel_Load.BackColor = Color.FromArgb(12, 12, 12);
            Panel_Load.Controls.Add(textBox1);
            Panel_Load.Controls.Add(checkBox1);
            Panel_Load.Controls.Add(button2);
            Panel_Load.Controls.Add(button1);
            Panel_Load.Controls.Add(label6);
            Panel_Load.Controls.Add(listBox2);
            Panel_Load.Controls.Add(progressBar1);
            Panel_Load.ForeColor = SystemColors.ButtonHighlight;
            Panel_Load.Location = new Point(0, 0);
            Panel_Load.Name = "Panel_Load";
            Panel_Load.Size = new Size(1099, 633);
            Panel_Load.TabIndex = 12;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.BackColor = Color.FromArgb(12, 12, 12);
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.ForeColor = SystemColors.Window;
            textBox1.Location = new Point(12, 560);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(775, 20);
            textBox1.TabIndex = 8;
            // 
            // checkBox1
            // 
            checkBox1.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(874, 560);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(213, 24);
            checkBox1.TabIndex = 7;
            checkBox1.Text = "Force Restart after Deletion";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            button2.ForeColor = SystemColors.ActiveCaptionText;
            button2.Location = new Point(793, 586);
            button2.Name = "button2";
            button2.Size = new Size(144, 29);
            button2.TabIndex = 6;
            button2.Text = "Cancel";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(943, 586);
            button1.Name = "button1";
            button1.Size = new Size(144, 29);
            button1.TabIndex = 5;
            button1.Text = "Confirm";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 30F);
            label6.ForeColor = Color.Red;
            label6.Location = new Point(604, 103);
            label6.Name = "label6";
            label6.Size = new Size(483, 67);
            label6.TabIndex = 4;
            label6.Text = "CONFIRM DELETION";
            // 
            // listBox2
            // 
            listBox2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listBox2.BackColor = Color.FromArgb(12, 12, 12);
            listBox2.ForeColor = SystemColors.Window;
            listBox2.FormattingEnabled = true;
            listBox2.Location = new Point(9, 164);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(1078, 384);
            listBox2.TabIndex = 1;
            // 
            // progressBar1
            // 
            progressBar1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            progressBar1.ForeColor = Color.Gold;
            progressBar1.Location = new Point(12, 586);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(775, 29);
            progressBar1.TabIndex = 0;
            // 
            // Interface
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Red;
            ClientSize = new Size(1099, 633);
            Controls.Add(Header_Panel);
            Controls.Add(Panel_Load);
            Controls.Add(Panel_Store);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Interface";
            Text = "Form1";
            Header_Panel.ResumeLayout(false);
            Header_Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            Panel_Store.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            Panel_Load.ResumeLayout(false);
            Panel_Load.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel Header_Panel;
        private Panel Panel_Store;
        private PictureBox pictureBox1;
        private Label label1;
        private Button button4;
        private ToolTip tooltip_frame;
        private Label label2;
        private ListBox listBoxInactive;
        private ListBox listBoxActive;
        private BindingSource bindingSource1;
        private Label label4;
        private Label label3;
        private ContextMenuStrip contextMenuStrip1;
        private Label label5;
        private ListBox listBox1;
        private PictureBox pictureBox2;
        private RichTextBox richTextBox1;
        private Panel panel1;
        private Panel panel4;
        private Panel panel3;
        private Panel panel2;
        private RichTextBox richTextBox2;
        private RichTextBox richTextBox3;
        private Panel Panel_Load;
        private ListBox listBox2;
        private ProgressBar progressBar1;
        private Label label6;
        private Button button2;
        private Button button1;
        private CheckBox checkBox1;
        private TextBox textBox1;
        private Label label7;
        private Label label8;
    }
}
